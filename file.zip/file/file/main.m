//
//  main.m
//  file
//
//  Created by Md Mostofa on 10/28/18.
//  Copyright © 2018 Md Mostofa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
